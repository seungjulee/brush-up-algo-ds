# 4 billions ints = 4 * 10^9 bytes
# 1 GB = 1 * 10^9 byte
# 10 MB = 10 * 10^6 * 8 bits
# assuming int = 64 bits = 8 bytes


